SET NAMES UTF8;
DROP DATABASE IF EXISTS ydw;
CREATE DATABASE ydw CHARSET=UTF8;
USE ydw;
#用户信息表
CREATE TABLE ydw_user(
	uid INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	uname VARCHAR(32),
	upwd VARCHAR(32),
	email VARCHAR(64),
	phone VARCHAR(16) NOT NULL UNIQUE,
	user_name VARCHAR(32)
);
INSERT INTO ydw_user VALUES
	("001","pdx1","123456","123456@qq.com","158123456","派大星1"),
	("002","pdx2","123456","123456@qq.com","158123457","派大星2"),
	("003","pdx3","123456","123456@qq.com","158123455","派大星3");
#首页轮播图表
CREATE TABLE ydw_index_carousel(
	cid INT PRIMARY KEY AUTO_INCREMENT,
	img VARCHAR(128),
	title VARCHAR(64),
	href VARCHAR(128)
)


