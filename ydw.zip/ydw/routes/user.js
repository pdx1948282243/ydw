const express=require('express');
const pool=require('../pool.js');
var router=express.Router();
router.get('/register',(req,res)=>{
    var $uname=req.query.uname;
    var $upwd=req.query.upwd;
    var sql="select * from ydw_user where uname=?";
    pool.query(sql,[$uname],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
          res.send('');
        }else{
            res.send('用户名已存在');
        }
    });
});

router.post('/login',(req,res)=>{
    var $uname=req.body.uname;
    var $upwd=req.body.upwd;
    console.log($uname,$upwd);
    if(!$uname){
        res.send('用户名不能为空');
        return;
    }
    if(!$upwd){
        res.send('密码不能为空');
        return;
    }
    //ִ连接数据库
    var sql='select * from ydw_user where uname=? and upwd=?';
    pool.query(sql,[$uname,$upwd],(err,result)=>{
        if(result.length>0){
        res.send('1');
    }else{
        res.send('0');
    }
    });
});
//导出路由
module.exports=router;