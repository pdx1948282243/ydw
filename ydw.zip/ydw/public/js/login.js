$(function() {
    new Vue({
        el: "#app",
        data: {
            myname:"",
            mypwd:"",
            namemsg: "",
            pwdmsg:"",
            alertStyle: {
                "alertFaile": false,
                "alertSuccess": false
            },
            alertStyle1: {
                "alertFaile": false,
                "alertSuccess": false
            }
        },
        watch:{
            myname(){
                var reg=/^1[345678]\d{9}$/
                if(reg.test(this.myname)){
                    this.namemsg="格式正确"
                    this.alertStyle["alertSuccess"]=true;
                    this.alertStyle["alertFaile"]=false;
                }else{
                    this.namemsg="用户名格式不正确"
                    this.alertStyle["alertSuccess"]=false;
                    this.alertStyle["alertFaile"]=true;
                }
            },
            mypwd(){
                var reg=/^[0-9-]{6,40}$/
                if(reg.test(this.mypwd)){
                    this.pwdmsg="格式正确"
                    this.alertStyle1["alertSuccess"]=true;
                    this.alertStyle1["alertFaile"]=false;
                }else{
                    this.pwdmsg="密码格式不正确"
                    this.alertStyle1["alertSuccess"]=false;
                    this.alertStyle1["alertFaile"]=true;
                }
            }
        }
    })
    $("[type=submit]").click(function(){
        var uname=$("[name=uname]").val();
        var upwd=$("[name=upwd]").val();
        $.ajax({
            url:"http://127.0.0.1:3000/user/login",
            type:"post",
            data:{uname,upwd},
            dataType:"json",
            success: function(result) {
                console.log(result);
                if(result==1){
                    //console.log("登录成功");
                    window.location.href="index.html";
                }else{
                    alert("用户名或者密码错误");
                }
            }
        })
     })
})