function userLogin(){
    var xhr=new XMLHttpRequest();
    xhr.onreadystatechange=function(){
        if(xhr.readyState==4&&xhr.status==200){
            var res=xhr.responseText;
            console.log(res);
            if(res=="1"){
         window.location.href="index.html";
                //console.log("�ɹ�");
            }else{
                console.log("��¼ʧ��");
            }
        }
    }
    xhr.open("post","/user/login",true);
    var input_uname=uname.value;
    var input_upwd=upwd.value
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded",charset=UTF-8);
    var formdata="uname="+input_uname+"&upwd="+input_upwd
    xhr.send(formdata);
}
