window.onload=function() {
    /*$("button").click(function(){
     $.ajax({
     url:"http://127.0.0.1:3000/login",
     type:"post",
     data:{uname,upwd},
     dataType:"json",
     success: function(result) {
     console.log(result);
     if(result=="1"){
     console.log("登录成功");
     // window.location.href="index.html";
     }else{
     console.log("用户名或者密码错误");
     }
     }
     })
     })*/
    new Vue({
        el: "#app",
        data: {
            myname:"",
            mypwd:"",
            namemsg: "",
            pwdmsg:"",
            alertStyle: {
                "alertFaile": false,
                "alertSuccess": false
            }
        },
        watch:{
            myname(){
                var reg=/^1[345678]\d{9}$/
                if(reg.test(this.myname)){
                    this.namemsg="验证通过"
                    this.alertStyle["alertSuccess"]=true;
                    this.alertStyle["alertFaile"]=false;
                }else{
                    this.namemsg="用户名格式不正确"
                    this.alertStyle["alertSuccess"]=false;
                    this.alertStyle["alertFaile"]=true;
                }
            },
            mypwd(){
                var reg=/^1[345678]\d{9}$/
                if(reg.test(this.mypwd)){
                    this.pwdmsg="验证通过"
                    this.alertStyle["alertSuccess"]=true;
                    this.alertStyle["alertFaile"]=false;
                }else{
                    this.pwdmsg="密码格式不正确"
                    this.alertStyle["alertSuccess"]=false;
                    this.alertStyle["alertFaile"]=true;
                }
            }


        }
    })
}