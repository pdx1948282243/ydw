$(function(){
    new Vue({
        el:"#app",
        data:{
          user:"",
          pwd:"",
          usemsg:"",
          pwdmsg:"",
          f_info_u:{
            display:"none"
          },
          s_info_u:{
            display:"none",
          },
          f_info_p:{
            display:"none"
          },
          s_info_p:{
            display:"none",
          }
        },
        watch:{
          user(){
            var reg=/^1[345678]\d{9}$/;
            if(reg.test(this.user)){
              //this.usemsg="用户名格式正确";
              this.s_info_u.display="inline-block";
              this.f_info_u.display="none";
              }else{
                  this.usemsg="用户名只允许字母、数字、下划线、横线组成，不支持纯数字， 需要 6-16个字符";
                  this.f_info_u.display="inline-block";
                  this.s_info_u.display="none";
              }
          },
          pwd(){
            var reg=/^1[345678]\d{9}$/;
            if(reg.test(this.pwd)){
              //this.usemsg="密码格式正确";
              this.s_info_p.display="inline-block";
              this.f_info_p.display="none";
              }else{
                this.pwdmsg="密码长度为6~16个字符";
                this.f_info_p.display="block";
                this.s_info_p.display="none";
              }
          }
        }
    })
    $("[type=submit]").click(function(){
        var uname=$("[name=uname]").val();
        var upwd=$("[name=upwd]").val();
        $.ajax({
            url:"http://127.0.0.1:3000/user/register",
            type:"get",
            data:{uname,upwd},
            dataType:"json",
            success: function(result) {
                console.log(result);
                if(result==1){
                    console.log("注册成功");
                    //window.location.href="login.html";
                }else{
                    alert("注册失败");
                }
            }
        })
    })
})