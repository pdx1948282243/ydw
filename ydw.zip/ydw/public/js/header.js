$(function(){
    // 头部
    $.ajax({
        url:"http://127.0.0.1:3000/header.html",
        type:"get",
        success:function(res){
            //console.log(res);
            $("<link rel='stylesheet' href='css/header.css'>").appendTo("head");
            $(res).replaceAll("#header");
            $("#ul li a").each(function(){
                if($(this)[0].href==String(window.location)){
                    $(".navAct").removeClass("navAct");
                    $(this).addClass("navAct");
                }
            })
        }
    })
    // 底部
    $.ajax({
        url:"http://127.0.0.1:3000/footer.html",
        type:"get",
        success:function(res){
            //console.log(res);
            $("<link rel='stylesheet' href='css/footer.css'>").appendTo("head");
            $(res).replaceAll("#footer");
        }
    })
})